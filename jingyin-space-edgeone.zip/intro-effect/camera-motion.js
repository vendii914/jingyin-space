// Detect local camera motion after removing whole-frame exposure changes.
// No frames leave the device. The first frame only establishes a baseline.
export class CameraMotion {
 constructor(width,height){this.width=width;this.height=height;this.previous=new Float32Array(width*height);this.ready=false;this.lastImpulse=-Infinity;}
 reset(){this.ready=false;this.lastImpulse=-Infinity;}
 update(rgba,time,emit){
  const {width:w,height:h,previous:p}=this;
  let global=0,count=0;
  for(let y=0;y<h;y+=3)for(let x=0;x<w;x+=3){const i=y*w+x,j=i*4;global+=(rgba[j]*.299+rgba[j+1]*.587+rgba[j+2]*.114)-p[i];count++;}
  global/=count;
  const cols=8,rows=6,bins=Array.from({length:cols*rows},()=>({weight:0,x:0,y:0,count:0}));
  for(let y=0;y<h;y+=3)for(let x=0;x<w;x+=3){
   const i=y*w+x,j=i*4,luma=rgba[j]*.299+rgba[j+1]*.587+rgba[j+2]*.114;
   const d=Math.max(0,Math.abs(luma-p[i]-global)-14);p[i]=luma;
   const b=bins[Math.min(rows-1,Math.floor(y/h*rows))*cols+Math.min(cols-1,Math.floor(x/w*cols))];
   b.weight+=d;b.x+=x*d;b.y+=y*d;b.count++;
  }
  if(!this.ready){this.ready=true;return 0;}
  if(time-this.lastImpulse<140)return 0;
  const active=bins.filter(b=>b.weight/b.count>4).sort((a,b)=>b.weight/b.count-a.weight/a.count);
  const points=[];
  for(const b of active){
   const u=b.x/b.weight/w,v=b.y/b.weight/h;
   if(points.some(q=>Math.hypot(q.u-u,q.v-v)<.23))continue;
   const strength=Math.min(2.3,.65+b.weight/b.count/30);
   emit(u,v,strength);points.push({u,v});if(points.length===3)break;
  }
  if(points.length)this.lastImpulse=time;
  return points.length;
 }
}
