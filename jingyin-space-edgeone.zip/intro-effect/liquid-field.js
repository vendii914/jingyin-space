import {BlobField} from './blob-field.js';

// Keep a continuous density field through coloring. Overlapping soft regions
// contribute to the same field, so necks and gaps blend before a rim is drawn.
export class LiquidField extends BlobField {
  constructor(width,height){
    super(width,height);
    this.density=new Float32Array(width*height);
    this.diffuse=new Float32Array(width*height);
    this.volume=new Float32Array(width*height);
    this.light=new Float32Array(width*height);
  }
  prepare(shape,halo,invert=false){
    const {density,diffuse,volume,light,width:w,height:h}=this;
    for(let i=0;i<shape.length;i++)density[i]=invert?1-shape[i]:shape[i];
    const radius=Math.max(1,Math.round(1+halo*.055));
    this.blur(density,radius);this.blur(density,radius);
    diffuse.set(density);
    this.blur(diffuse,Math.round(radius*1.8));
    this.blur(diffuse,Math.round(radius*1.8));
    volume.set(diffuse);
    this.blur(volume,Math.round(12+halo*.14));
    this.blur(volume,Math.round(8+halo*.1));
    for(let i=0;i<density.length;i++)density[i]=density[i]*.80+diffuse[i]*.14+(invert?1-shape[i]:shape[i])*.06;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=y*w+x;
      const dx=diffuse[y*w+Math.min(w-1,x+1)]-diffuse[y*w+Math.max(0,x-1)];
      const dy=diffuse[Math.min(h-1,y+1)*w+x]-diffuse[Math.max(0,y-1)*w+x];
      light[i]=Math.max(-1,Math.min(1,(-dx*.6-dy*.8)*12));
    }
  }
  sampleArray(a,x,y){
    const {width:w,height:h}=this;
    x=Math.max(0,Math.min(w-1,x));y=Math.max(0,Math.min(h-1,y));
    const x0=Math.floor(x),y0=Math.floor(y),x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),fx=x-x0,fy=y-y0;
    return (a[y0*w+x0]*(1-fx)+a[y0*w+x1]*fx)*(1-fy)+(a[y1*w+x0]*(1-fx)+a[y1*w+x1]*fx)*fy;
  }
}
export function smoothRange(a,b,x){const v=Math.max(0,Math.min(1,(x-a)/(b-a)));return v*v*(3-2*v);}
