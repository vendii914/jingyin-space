# Third-party notices

This application includes Google MediaPipe Tasks Vision 0.10.22-rc.20250304 and the MediaPipe Selfie Segmenter float16 model.

- Copyright Google LLC / The MediaPipe Authors.
- MediaPipe source: https://github.com/google-ai-edge/mediapipe
- Distributed package: https://www.npmjs.com/package/@mediapipe/tasks-vision
- License: Apache License 2.0. See vendor/LICENSE.
- Model source: https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite
- Model documentation: https://developers.google.com/edge/mediapipe/solutions/vision/image_segmenter

This is an independently implemented visual recreation based on user-provided visual references. It is not the original Thermal Camera application and is not affiliated with its creator.
