// Work on broad spatial regions before generating any colored contour.
// All radii are in this small analysis grid, independent of export resolution.
export class BlobField {
  constructor(width = 160, height = 107) {
    this.width = width; this.height = height;
    const n = width * height;
    this.values = new Float32Array(n);
    this.scratch = new Float32Array(n);
    this.history = new Float32Array(n);
    this.mask = new Uint8Array(n);
    this.visited = new Uint8Array(n);
    this.queue = new Int32Array(n);
    this.ready = false;
  }
  reset() { this.ready = false; }
  blur(values, radius) {
    const {width:w, height:h, scratch} = this;
    const span = radius * 2 + 1;
    for (let y=0; y<h; y++) {
      const row=y*w;
      let sum=0;
      for (let k=-radius;k<=radius;k++) sum+=values[row+Math.max(0,Math.min(w-1,k))];
      for (let x=0;x<w;x++) {
        scratch[row+x]=sum/span;
        sum+=values[row+Math.min(w-1,x+radius+1)]-values[row+Math.max(0,x-radius)];
      }
    }
    for (let x=0;x<w;x++) {
      let sum=0;
      for (let k=-radius;k<=radius;k++) sum+=scratch[Math.max(0,Math.min(h-1,k))*w+x];
      for (let y=0;y<h;y++) {
        values[y*w+x]=sum/span;
        sum+=scratch[Math.min(h-1,y+radius+1)*w+x]-scratch[Math.max(0,y-radius)*w+x];
      }
    }
  }
  extremum(radius, dilate) {
    const {width:w,height:h,mask,scratch}=this;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      let value=dilate?0:1;
      for(let k=-radius;k<=radius;k++){
        const sample=mask[y*w+Math.max(0,Math.min(w-1,x+k))];
        value=dilate?Math.max(value,sample):Math.min(value,sample);
      }
      scratch[y*w+x]=value;
    }
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      let value=dilate?0:1;
      for(let k=-radius;k<=radius;k++){
        const sample=scratch[Math.max(0,Math.min(h-1,y+k))*w+x];
        value=dilate?Math.max(value,sample):Math.min(value,sample);
      }
      mask[y*w+x]=value;
    }
  }
  cleanRegions() {
    const {width:w,height:h,mask,visited,queue}=this;
    visited.fill(0);
    const minIsland=Math.round(w*h*.0035),maxHole=Math.round(w*h*.055);
    for(let start=0;start<mask.length;start++){
      if(visited[start])continue;
      const value=mask[start];let head=0,tail=1,touchesEdge=false;
      queue[0]=start;visited[start]=1;
      while(head<tail){
        const i=queue[head++],x=i%w,y=Math.floor(i/w);
        if(x===0||x===w-1||y===0||y===h-1)touchesEdge=true;
        const add=j=>{if(!visited[j]&&mask[j]===value){visited[j]=1;queue[tail++]=j;}};
        if(x)add(i-1);if(x<w-1)add(i+1);if(y)add(i-w);if(y<h-1)add(i+w);
      }
      // Keep large background openings and objects intersecting the frame edge.
      if(!touchesEdge&&((value===1&&tail<minIsland)||(value===0&&tail<maxHole)))
        for(let j=0;j<tail;j++)mask[queue[j]]=1-value;
    }
  }
  process(rgba,{person=false,sensitivity=.8,smoothing=0,advance=true,dt=33,support=null}={}) {
    const {values,mask,history}=this;
    for(let i=0;i<values.length;i++){
      const j=i*4;
      values[i]=(rgba[j]*.299+rgba[j+1]*.587+rgba[j+2]*.114)/255;
    }
    // This baseline removes texture even when the user's extra smoothing is zero.
    const radius=person?1:3+Math.round(smoothing/35);
    this.blur(values,radius);this.blur(values,radius);
    const threshold=person?Math.max(.05,Math.min(.95,.82-sensitivity*.4)):Math.max(15/255,Math.min(240/255,130*sensitivity/255));
    for(let i=0;i<mask.length;i++)mask[i]=person?+(values[i]>threshold):+(values[i]<threshold);
    // Person support unifies light clothing and skin without deleting the scene.
    if(support&&!person)for(let i=0;i<mask.length;i++)if(support[i*4]>115)mask[i]=1;
    this.extremum(person?1:3,true);
    this.extremum(person?1:3,false);
    this.cleanRegions();
    for(let i=0;i<mask.length;i++)values[i]=mask[i];
    // Round the surviving shapes; do not merely blur the final colored picture.
    this.blur(values,2+Math.round(smoothing/50));
    this.blur(values,2);
    const alpha=1-Math.exp(-Math.min(dt,100)/(45+smoothing*.75));
    for(let i=0;i<values.length;i++){
      if(!this.ready||!advance)history[i]=values[i];
      else history[i]+=(values[i]-history[i])*alpha;
    }
    this.ready=true;
    return history;
  }
  sample(x,y) {
    const {width:w,height:h,history:a}=this;
    x=Math.max(0,Math.min(w-1,x));y=Math.max(0,Math.min(h-1,y));
    const x0=Math.floor(x),y0=Math.floor(y),x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),fx=x-x0,fy=y-y0;
    return (a[y0*w+x0]*(1-fx)+a[y0*w+x1]*fx)*(1-fy)+(a[y1*w+x0]*(1-fx)+a[y1*w+x1]*fx)*fy;
  }
}
