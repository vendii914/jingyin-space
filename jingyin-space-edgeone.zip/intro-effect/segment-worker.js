let segmenter;
self.onmessage=async({data})=>{
 try{
  if(data.type==='init'){
   const {FilesetResolver,ImageSegmenter}=await import('./vendor/vision_bundle.mjs');
   const files=await FilesetResolver.forVisionTasks(new URL('./vendor/wasm/',self.location.href).href);
   segmenter=await ImageSegmenter.createFromOptions(files,{baseOptions:{modelAssetPath:new URL('./vendor/selfie_segmenter.tflite',self.location.href).href,delegate:'CPU'},runningMode:'VIDEO',outputCategoryMask:false,outputConfidenceMasks:true});
   self.postMessage({type:'ready'});
  }else if(data.type==='frame'&&segmenter){
   try{segmenter.segmentForVideo(data.bitmap,data.timestamp,result=>{const m=result.confidenceMasks[0],floats=m.getAsFloat32Array(),mask=new Uint8Array(floats.length);for(let i=0;i<floats.length;i++)mask[i]=Math.round(floats[i]*255);self.postMessage({type:'mask',width:m.width,height:m.height,mask},[mask.buffer]);});}finally{data.bitmap.close();}
  }
 }catch(error){self.postMessage({type:'error',message:String(error)});}
};
