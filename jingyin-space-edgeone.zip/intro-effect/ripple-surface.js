// Damped wave surface. Input supplies energy; there is no autonomous animation.
export class RippleSurface {
 constructor(width,height){
  this.width=width;this.height=height;this.heightMap=new Float32Array(width*height);
  this.previous=new Float32Array(width*height);this.next=new Float32Array(width*height);
  this.dx=new Float32Array(width*height);this.dy=new Float32Array(width*height);
  this.base=new Float32Array(width*height);this.accumulator=0;
  this.flowX=0;this.flowY=0;this.targetX=0;this.targetY=0;this.energy=0;this.phase=0;
  this.phaseGoal=0;this.lastFlow=null;this.rebuildBase();
 }
 flow(u,v,gain=1){
  const distance=this.lastFlow?Math.hypot(u-this.lastFlow.u,v-this.lastFlow.v):.08;
  this.targetX=(u-.5)*2*gain;this.targetY=(v-.5)*2*gain;
  this.energy=Math.min(gain,this.energy+distance*4*gain);
  this.phaseGoal+=distance*7*gain;
  this.lastFlow={u,v};
 }
 release(){this.targetX=0;this.targetY=0;this.lastFlow=null;}
 rebuildBase(){
  const {width,height,flowX:fx,flowY:fy,energy,phase:p}=this;
  // Unequal moving lobes share one density field: connections form and break.
  const lobes=[];
  for(let k=0;k<7;k++){
   const angle=k*2.399+p*(k%2?.56:-.43);
   const spread=.25+.15*Math.sin(p*.72+k*.82);
   const pull=.14+.13*Math.sin(k*1.7+p*.35);
   const cx=.5+Math.cos(angle)*spread+fx*pull;
   const cy=.5+Math.sin(angle)*spread*1.25+fy*pull;
   const radius=(.105+.035*(1+Math.sin(p*.8+k*2.1)))*Math.SQRT2;
   const stretch=1+energy*.7*Math.sin(p+k);
   const rotation=angle+p*.4;
   lobes.push({cx,cy,rx:radius*stretch,ry:radius/Math.sqrt(stretch),co:Math.cos(rotation),si:Math.sin(rotation)});
  }
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
   const px=x/width,py=y/height;
   const u=px-energy*.105*Math.sin(py*9+p+fx*2);
   const v=py-energy*.095*Math.sin(px*8-p*.7+fy*2);
   let field=0;
   for(const l of lobes){
    const dx=u-l.cx,dy=v-l.cy;
    const a=(dx*l.co+dy*l.si)/l.rx,b=(-dx*l.si+dy*l.co)/l.ry;
    field+=Math.exp(-(a*a+b*b)*1.7);
   }
   const q=Math.max(0,Math.min(1,(field-.48)/.25));
   this.base[y*width+x]=q*q*(3-2*q);
  }
 }

 clear(){this.heightMap.fill(0);this.previous.fill(0);this.next.fill(0);this.dx.fill(0);this.dy.fill(0);this.accumulator=0;this.flowX=this.flowY=this.targetX=this.targetY=this.energy=this.phase=this.phaseGoal=0;this.lastFlow=null;this.rebuildBase();}
 disturb(u,v,strength=1){
  const {width:w,height:h,heightMap:a,previous:p}=this;
  const cx=u*(w-1),cy=v*(h-1),radius=4.2;
  for(let y=Math.max(1,Math.floor(cy-10));y<Math.min(h-1,cy+11);y++)for(let x=Math.max(1,Math.floor(cx-10));x<Math.min(w-1,cx+11);x++){
   const impulse=Math.exp(-((x-cx)**2+(y-cy)**2)/(2*radius*radius))*strength;
   const i=y*w+x; a[i]=Math.max(-3,Math.min(3,a[i]+impulse));
   p[i]=Math.max(-3,Math.min(3,p[i]+impulse*.65));
  }
 }
 step(ms){
  const {width:w,height:h}=this;
  const dt=Math.min(100,Math.max(0,ms));
  const morphDt=dt*.25; // Half the previous morph speed; waves retain their own timing.
  const ease=1-Math.exp(-morphDt/190);
  this.flowX+=(this.targetX-this.flowX)*ease;
  this.flowY+=(this.targetY-this.flowY)*ease;
  this.phase+=(this.phaseGoal-this.phase)*(1-Math.exp(-morphDt/260));
  this.energy*=Math.exp(-morphDt/1600);
  this.targetX*=Math.exp(-morphDt/1500);this.targetY*=Math.exp(-morphDt/1500);
  if(Math.abs(this.flowX)+Math.abs(this.flowY)+this.energy<.0001){this.flowX=this.flowY=this.targetX=this.targetY=this.energy=0;}
  this.rebuildBase();
  this.accumulator+=dt;
  while(this.accumulator>=1000/60){
   const a=this.heightMap,p=this.previous,n=this.next;
   for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
    const i=y*w+x,lap=a[i-1]+a[i+1]+a[i-w]+a[i+w]-4*a[i];
    // Absorb waves near boundaries instead of reflecting them indefinitely.
    const edge=Math.min(x,w-1-x,y,h-1-y),damp=edge<8?.82+.019*edge:.972;
    n[i]=(2*a[i]-p[i]+.25*lap)*damp;
   }
   this.previous=a;this.heightMap=n;this.next=p;this.accumulator-=1000/60;
  }
  const a=this.heightMap;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
   const i=y*w+x;
   this.dx[i]=(a[y*w+Math.min(w-1,x+1)]-a[y*w+Math.max(0,x-1)])*.5;
   this.dy[i]=(a[Math.min(h-1,y+1)*w+x]-a[Math.max(0,y-1)*w+x])*.5;
  }
 }
}
