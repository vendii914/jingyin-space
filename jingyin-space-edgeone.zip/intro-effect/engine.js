import {CameraMotion} from './camera-motion.js';
import {BlobField} from './blob-field.js';
import {LiquidField,smoothRange} from './liquid-field.js';
import {RippleSurface} from './ripple-surface.js';

export function createIntroEffect(canvas,onState){
 const W=480,H=320,ctx=canvas.getContext('2d');
 if(!ctx)throw Error('Canvas unavailable');
 canvas.width=W;canvas.height=H;
 const blobs=new BlobField(),liquid=new LiquidField(blobs.width,blobs.height),water=new RippleSurface(blobs.width,blobs.height);
 const motion=new CameraMotion(blobs.width,blobs.height);
 let lastMotionFrame=-1;
 const makeCanvas=(w,h)=>Object.assign(document.createElement('canvas'),{width:w,height:h});
 const source=makeCanvas(blobs.width,blobs.height),sc=source.getContext('2d',{willReadFrequently:true});
 const support=makeCanvas(blobs.width,blobs.height),supportContext=support.getContext('2d',{willReadFrequently:true});
 const mask=makeCanvas(1,1),mc=mask.getContext('2d');
 const pixels=ctx.createImageData(W,H),bg=[108,234,175],palette=new Uint8Array(3072);
 const stops=[[2,[26,86,255]],[25,[186,94,179]],[36,[58,149,91]],[56,[255,255,163]],[88,[172,103,210]],[100,[199,201,255]]];
 for(let i=0;i<1024;i++){
  const t=i/1023*100;let a=stops[0],b=stops.at(-1);
  if(t<=a[0])b=a;else if(t>=b[0])a=b;else for(let j=1;j<stops.length;j++)if(t<=stops[j][0]){a=stops[j-1];b=stops[j];break;}
  const q=a===b?0:(t-a[0])/(b[0]-a[0]);for(let c=0;c<3;c++)palette[i*3+c]=a[1][c]+(b[1][c]-a[1][c])*q;
 }
 const video=document.createElement('video');video.muted=true;video.autoplay=true;video.playsInline=true;video.hidden=true;canvas.parentElement.append(video);
 let disposed=false,stream=null,worker=null,modelReady=false,maskReady=false,busy=false,wanted=false,generation=0,frameId=0,workerTimer=0;
 let last=0,elapsed=0,lastInference=0,lastVideoTime=-1,lastPointer=null,lastImpulse=0;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function report(state,message){if(!disposed)onState({state,message});}
 function releaseCamera(){
  generation++;wanted=false;stream?.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;
  worker?.terminate();worker=null;clearTimeout(workerTimer);modelReady=false;maskReady=false;busy=false;blobs.reset();motion.reset();lastMotionFrame=-1;lastVideoTime=-1;
 }
 function stopCamera(){releaseCamera();water.clear();lastPointer=null;report('mouse','');}
 function fail(message){releaseCamera();report('mouse',message+' 已恢复鼠标玩法。');}
 async function setCamera(enabled){
  if(disposed)return;
  if(!enabled){stopCamera();return;}
  if(wanted)return;
  wanted=true;const token=++generation;report('loading','请允许摄像头权限；画面只在你的设备上处理。');
  try{
   if(!navigator.mediaDevices?.getUserMedia)throw Object.assign(new Error(),{name:'Unavailable'});
   const acquired=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:960},height:{ideal:640},facingMode:'user'},audio:false});
   if(disposed||token!==generation){acquired.getTracks().forEach(t=>t.stop());return;}
   stream=acquired;video.srcObject=stream;await video.play();
   if(disposed||token!==generation)return;
   stream.getVideoTracks()[0].addEventListener('ended',()=>{if(token===generation)fail('摄像头连接已结束。');},{once:true});
   water.clear();blobs.reset();
   report('camera','挥手或移动身体，让光晕和涟漪随你变化；也可划动或点击液面。');
   worker=new Worker(new URL('./segment-worker.js',import.meta.url));
   workerTimer=setTimeout(()=>{if(token===generation)fail('人像识别载入超时。');},20000);
   worker.onmessage=({data})=>{
    if(disposed||token!==generation)return;
    if(data.type==='ready'){clearTimeout(workerTimer);modelReady=true;}
    else if(data.type==='mask'){
     busy=false;mask.width=data.width;mask.height=data.height;const im=mc.createImageData(mask.width,mask.height);
     for(let i=0;i<data.mask.length;i++){im.data[i*4]=im.data[i*4+1]=im.data[i*4+2]=data.mask[i];im.data[i*4+3]=255;}
     mc.putImageData(im,0,0);maskReady=true;
    }else if(data.type==='error')fail('人像识别暂时不可用。');
   };
   worker.onerror=()=>{if(token===generation)fail('人像识别暂时不可用。');};worker.postMessage({type:'init'});
  }catch(error){
   if(disposed||token!==generation)return;
   const messages={NotAllowedError:'摄像头权限未开启，可在地址栏的网站设置中允许后重试。',NotFoundError:'未找到摄像头。',NotReadableError:'摄像头可能被其他应用占用。',Unavailable:'此浏览器无法开启摄像头，请使用本机地址或 HTTPS。'};
   fail(messages[error.name]||'摄像头启动失败，请重试。');
  }
 }
 function cover(context,input){
  const sw=input.videoWidth||input.width,sh=input.videoHeight||input.height,w=blobs.width,h=blobs.height;
  if(!sw||!sh)return;const scale=Math.max(w/sw,h/sh);
  context.save();context.translate(w,0);context.scale(-1,1);context.drawImage(input,(w-sw*scale)/2,(h-sh*scale)/2,sw*scale,sh*scale);context.restore();
 }
 async function infer(t){
  if(!stream||!modelReady||busy||t-lastInference<90||video.currentTime===lastVideoTime)return;
  busy=true;lastInference=t;lastVideoTime=video.currentTime;const currentWorker=worker,token=generation;
  try{
   const bitmap=await createImageBitmap(video,{resizeWidth:480,resizeHeight:Math.round(480*video.videoHeight/video.videoWidth)});
   if(disposed||token!==generation||currentWorker!==worker){bitmap.close();return;}
   currentWorker.postMessage({type:'frame',bitmap,timestamp:t},[bitmap]);
  }catch{if(token===generation)busy=false;}
 }
 function pointer(u,v,click=false){
  if(disposed)return;
  if(!wanted)water.flow(u,v,reduced?.35:1);
  const now=performance.now();
  if(click){water.disturb(u,v,reduced?.8:2.8);lastImpulse=now;}
  else if(lastPointer&&now-lastImpulse>25){
   const d=Math.hypot((u-lastPointer.u)*water.width,(v-lastPointer.v)*water.height);
   if(d>.1){water.disturb(u,v,Math.min(1.5,d*.2)*(reduced?.4:1));lastImpulse=now;}
  }
  lastPointer={u,v};
 }
 function leave(){lastPointer=null;water.release();}

 function render(t){
 liquid.prepare(blobs.history,50.98,false);
 const grain=15*.32,scale=Math.max(1,10/7),data=pixels.data;
 const seed=Math.floor(t/100);
 const anchors=[[0,1],[.25,.88],[.40,.69],[.46,.60],[.50,.56],[.54,.49],[.66,.36],[1,.12]];
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){
   const i=y*W+x,ux=(x+.5)*liquid.width/W-.5,uy=(y+.5)*liquid.height/H-.5;
   const wx=liquid.sampleArray(water.dx,ux,uy);
   const wy=liquid.sampleArray(water.dy,ux,uy);
   const sx=ux+Math.max(-.7,Math.min(.7,wx))*42,sy=uy+Math.max(-.7,Math.min(.7,wy))*42;
   const waterLight=Math.max(-.6,Math.min(.6,-wx*.7-wy))*110;
   const q=liquid.sampleArray(liquid.density,sx,sy);
   const volume=liquid.sampleArray(liquid.volume,sx,sy);
   const light=liquid.sampleArray(liquid.light,sx,sy);
   // A narrow luminous crest, a wider green shoulder, and a diffuse violet side.
   // Compress the bright crest while keeping broad colored shoulders.
   let v=1;
   for(let k=1;k<anchors.length;k++)if(q<=anchors[k][0]){
     const a=anchors[k-1],b=anchors[k],u=(q-a[0])/(b[0]-a[0]);
     v=a[1]+(b[1]-a[1])*u;break;
   }
   const p=Math.round(Math.max(0,Math.min(1,v))*1023)*3;
   const interior=smoothRange(.64,.95,q);
   const crest=Math.exp(-Math.pow((q-.5)/.035,2));
   const shoulder=4*q*(1-q);
   const softShade=(1-volume)*smoothRange(.5,.88,q);
   let hash=(Math.floor(x/scale)*374761393+Math.floor(y/scale)*668265263+seed*69069)|0;
   hash=Math.imul(hash^(hash>>>13),1274126177);
   const noise=((hash>>>0)/4294967295-.5)*grain;
   for(let c=0;c<3;c++){
     // Broad shape-derived shading; camera texture never enters this material.
     const body=bg[c]-(c===0?39:c===1?22:0)*softShade+light*9;
     const color=palette[p+c]*(1-interior)+body*interior;
     const rimLight=crest*(c===2?21:8)*(1+light*.22);
     data[i*4+c]=color+rimLight+light*shoulder*6+waterLight+noise;
   }
   data[i*4+3]=255;
 }
 ctx.putImageData(pixels,0,0);
}
 function tick(t){
  if(disposed)return;
  if(!document.hidden&&t-last>=33){
   const dt=Math.min(100,t-last||33);last=t;elapsed+=dt;
   if(stream&&video.readyState>=2){
    cover(sc,video);const cameraPixels=sc.getImageData(0,0,blobs.width,blobs.height).data;
    if(video.currentTime!==lastMotionFrame){
     motion.update(cameraPixels,t,(u,v,strength)=>water.disturb(u,v,strength*(reduced?.35:1)));
     lastMotionFrame=video.currentTime;
    }
    water.step(dt);
    let personSupport=null;
    if(maskReady){cover(supportContext,mask);personSupport=supportContext.getImageData(0,0,blobs.width,blobs.height).data;}
    blobs.process(cameraPixels,{sensitivity:.8,smoothing:0,dt,support:personSupport});infer(t);
   }else{water.step(dt);blobs.history.set(water.base);}
   render(elapsed);

  }
  frameId=requestAnimationFrame(tick);
 }
 function destroy(){if(disposed)return;disposed=true;releaseCamera();cancelAnimationFrame(frameId);video.remove();window.removeEventListener('pagehide',destroy);}
 window.addEventListener('pagehide',destroy);
 report('mouse','');
 frameId=requestAnimationFrame(tick);
 return {setCamera,destroy,pointer,leave};
}
